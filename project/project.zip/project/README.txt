1. To run solar.jar in main.cmd

-> click main.cmd

2. To run solar.jar in command line

-> java -cp "solar.jar;lib/*" solar